import logo from './logo.svg';
import './App.css';
import Introducing from './components/Introducing';
import ButtonTabs from './components/ButtonTabs';
import Try from './components/Try';

function App() {
  return (
    <div >
      {/* <Introducing/> */}
      <Try/>
      <ButtonTabs/>
    </div>
  );
}

export default App;
